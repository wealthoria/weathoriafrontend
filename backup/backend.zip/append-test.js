require("dotenv").config();

const { ImapFlow } = require("imapflow");

async function run() {
  const client = new ImapFlow({
    host: "imap.hostinger.com",
    port: 993,
    secure: true,
    auth: {
      user: process.env.SMTP_EMAIL,
      pass: process.env.SMTP_PASSWORD,
    },
  });

  await client.connect();

  const rawEmail = `From: ${process.env.SMTP_EMAIL}
To: ${process.env.SMTP_EMAIL}
Subject: IMAP Append Test
Date: ${new Date().toUTCString()}
MIME-Version: 1.0
Content-Type: text/plain; charset=UTF-8

This email was appended using IMAP.
`;

  await client.append("INBOX.Sent", rawEmail, ["\\Seen"]);

  console.log("✅ Email appended to Sent folder.");

  await client.logout();
}

run().catch(console.error);