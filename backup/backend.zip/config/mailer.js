const nodemailer = require("nodemailer");
const dns = require("dns");

const transporter = nodemailer.createTransport({
  host: "smtp.hostinger.com",
  port: 587,
  secure: false,
  requireTLS: true,

  auth: {
    user: process.env.SMTP_EMAIL,
    pass: process.env.SMTP_PASSWORD,
  },

  lookup(hostname, options, callback) {
    return dns.lookup(hostname, { family: 4 }, callback);
  },

  logger: true,
  debug: true,
});

module.exports = transporter;