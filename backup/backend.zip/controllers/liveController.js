const RECORDED_VIDEO_ID = "368fd8f7617446e392ccf84277e15e82";

const jwt = require("jsonwebtoken");
const crypto = require("crypto");
const axios = require("axios"); 
const { getPaidUser } = require("../models/webinarModel");

const generateLiveToken = async (req, res) => {
  try {
    const email = req.query.email;
    const adminToken = req.query.adminToken;

    // Allow admin without payment check
    if (adminToken === process.env.ADMIN_WEBINAR_TOKEN) {
      const payload = {
        userId: crypto.randomUUID(),
        userInfo: {
          username: "Wealthoria Admin",
          avatar: "",
        },
      };

      const token = jwt.sign(payload, process.env.VDO_CHAT_SECRET, {
        algorithm: "HS256",
        noTimestamp: true,
      });

      return res.json({
        success: true,
        token,
      });
    }

    // Normal paid user flow
    if (!email) {
      return res.status(400).json({
        success: false,
        message: "Email is required",
      });
    }

    const user = await getPaidUser(email);

    if (!user) {
      return res.status(403).json({
        success: false,
        message: "Access denied. Payment not found.",
      });
    }


// Webinar end time (adjust if required)
const webinarEndTime = new Date("2025-01-01T00:00:00+05:30");
if (new Date() >= webinarEndTime) {

  const otpResponse = await axios.post(
    `https://dev.vdocipher.com/api/videos/${RECORDED_VIDEO_ID}/otp`,
    {
      ttl: 3600,
    },
    {
      headers: {
        Authorization: `Apisecret ${process.env.VDO_API_SECRET}`,
        "Content-Type": "application/json",
      },
    }
  );

  return res.json({
    success: true,
    type: "recorded",
    otp: otpResponse.data.otp,
    playbackInfo: otpResponse.data.playbackInfo,
  });
}

    const payload = {
      userId: crypto.randomUUID(),
      userInfo: {
        username: user.full_name,
        avatar: "",
      },
    };

    const token = jwt.sign(payload, process.env.VDO_CHAT_SECRET, {
      algorithm: "HS256",
      noTimestamp: true,
    });

    return res.json({
      success: true,
      token,
    });

  } catch (err) {
    console.error(err);

    return res.status(500).json({
      success: false,
      message: err.message,
    });
  }
};


// ======================================
// ;

module.exports = {
  generateLiveToken,
};