const jwt = require("jsonwebtoken");

const generateLiveToken = async (req, res) => {
  try {
    // For testing
 const payload = {
  userId: "user123",
  userInfo: {
    username: "Anjali",
    avatar: "",
  },
};

const token = jwt.sign(payload, process.env.VDO_CHAT_SECRET, {
  algorithm: "HS256",
  expiresIn: "1h",
});

    console.log("Generated Token:", token);

    res.json({
      success: true,
      token,
    });
  } catch (error) {
    console.error("JWT Error:", error);

    res.status(500).json({
      success: false,
      message: "Failed to generate token",
      error: error.message,
    });
  }
};

module.exports = {
  generateLiveToken,
};