const razorpay = require("../config/razorpay");
const transporter = require("../config/mailer");
const crypto = require("crypto");
const jwt = require("jsonwebtoken");

const { admin, db } = require("../config/firebaseAdmin");

/* =========================================================
   EXISTING GENERIC ORDER
========================================================= */

const createOrder = async (req, res) => {

  try {

    const { amount } = req.body;

    if (!amount || Number(amount) <= 0) {

      return res.status(400).json({
        success: false,
        message: "Valid amount is required."
      });

    }

    const options = {

      amount:
        Math.round(Number(amount) * 100),

      currency: "INR",

      receipt:
        "receipt_" + Date.now()

    };

    const order =
      await razorpay.orders.create(
        options
      );

    res.json(order);

  } catch (err) {

    console.error(
      "Create Order Error:",
      err
    );

    res.status(500).json({

      success: false,

      message:
        err.message

    });

  }

};


/* =========================================================
   CREATE COURSE ORDER
========================================================= */

const createCourseOrder = async (
  req,
  res
) => {

  try {

    const {
      courseId,
      amount
    } = req.body;


    if (!courseId) {

      return res.status(400).json({

        success: false,

        message:
          "Course ID is required."

      });

    }


    if (!amount || Number(amount) <= 0) {

      return res.status(400).json({

        success: false,

        message:
          "Valid course amount is required."

      });

    }


    const order =
      await razorpay.orders.create({

        amount:
          Math.round(
            Number(amount) * 100
          ),

        currency: "INR",

        receipt:
          `course_${courseId}_${Date.now()}`,

        notes: {

          courseId:
            String(courseId)

        }

      });


    res.json({

      success: true,

      keyId:
        process.env.RAZORPAY_KEY_ID,

      orderId:
        order.id,

      amount:
        order.amount,

      currency:
        order.currency,

      courseId:
        String(courseId)

    });

  } catch (err) {

    console.error(
      "Create Course Order Error:",
      err
    );

    res.status(500).json({

      success: false,

      message:
        err.message ||
        "Unable to create course order."

    });

  }

};


/* =========================================================
   VERIFY COURSE PAYMENT
========================================================= */
const verifyCoursePayment = async (req, res) => {

  try {

    const {
      courseId,
      courseTitle,
      amount,
      razorpay_order_id,
      razorpay_payment_id,
      razorpay_signature
    } = req.body;


    /* =====================================================
       1. REQUIRED PAYMENT FIELDS
    ===================================================== */

    if (
      !courseId ||
      !razorpay_order_id ||
      !razorpay_payment_id ||
      !razorpay_signature
    ) {

      return res.status(400).json({
        success: false,
        paid: false,
        message: "Missing payment verification fields."
      });

    }


    /* =====================================================
       2. VERIFY FIREBASE USER
    ===================================================== */
/* =====================================================
   2. VERIFY MEMBER JWT
===================================================== */

const authorization =
  req.headers.authorization || "";


if (
  !authorization.startsWith(
    "Bearer "
  )
) {

  return res.status(401).json({
    success: false,
    paid: false,
    message:
      "Member authentication token is required."
  });

}


const token =
  authorization.substring(7);


const JWT_SECRET =
  process.env.MEMBER_JWT_SECRET;


if (!JWT_SECRET) {

  console.error(
    "MEMBER_JWT_SECRET is not configured."
  );

  return res.status(500).json({
    success: false,
    paid: false,
    message:
      "Member authentication is not configured."
  });

}


let memberUser;

try {

  
  memberUser =
    jwt.verify(
      token,
      JWT_SECRET
    );

} catch (error) {

  console.error(
    "Member JWT verification failed:",
    error
  );

  return res.status(401).json({
    success: false,
    paid: false,
    message:
      "Invalid member authentication token."
  });

}


if (
  !memberUser ||
  !memberUser.uid
) {

  return res.status(401).json({
    success: false,
    paid: false,
    message:
      "Invalid member authentication token."
  });

}

    /* =====================================================
       3. VERIFY RAZORPAY SIGNATURE
    ===================================================== */

    const expectedSignature =
      crypto
        .createHmac(
          "sha256",
          process.env.RAZORPAY_KEY_SECRET
        )
        .update(
          `${razorpay_order_id}|${razorpay_payment_id}`
        )
        .digest("hex");


    const expectedBuffer =
      Buffer.from(
        expectedSignature,
        "utf8"
      );

    const receivedBuffer =
      Buffer.from(
        razorpay_signature,
        "utf8"
      );


    if (
      expectedBuffer.length !==
      receivedBuffer.length
    ) {

      return res.status(400).json({
        success: false,
        paid: false,
        message: "Payment signature verification failed."
      });

    }


    const isValid =
      crypto.timingSafeEqual(
        expectedBuffer,
        receivedBuffer
      );


    if (!isValid) {

      return res.status(400).json({
        success: false,
        paid: false,
        message: "Payment signature verification failed."
      });

    }


   console.log(
  "Course payment verified:",
  {
    uid: memberUser.uid,
    email: memberUser.email,
    courseId,
    razorpay_order_id,
    razorpay_payment_id
  }
);

    /* =====================================================
       4. SAVE PURCHASE TO FIRESTORE
    ===================================================== */

    const purchaseRef =
      await db
        .collection("coursePurchases")
        .add({

          userId:
             memberUser.uid,

          userEmail:
           memberUser.email || "",

          courseId:
            String(courseId),

          courseTitle:
            courseTitle || "",

          amount:
            Number(amount || 0),

          razorpayOrderId:
            razorpay_order_id,

          razorpayPaymentId:
            razorpay_payment_id,

          status:
            "paid",

          paidAt:
            admin.firestore.FieldValue.serverTimestamp(),

          createdAt:
            admin.firestore.FieldValue.serverTimestamp()

        });


    console.log(
      "Course purchase saved:",
      purchaseRef.id
    );


    /* =====================================================
       5. SUCCESS
    ===================================================== */

    return res.json({

      success: true,

      paid: true,

      courseId:
        String(courseId),

      orderId:
        razorpay_order_id,

      paymentId:
        razorpay_payment_id,

      purchaseId:
        purchaseRef.id

    });


  } catch (err) {

    console.error(
      "Verify Course Payment Error:",
      err
    );

    return res.status(500).json({

      success: false,

      paid: false,

      message:
        err.message ||
        "Unable to verify payment."

    });

  }

};


/* =========================================================
   RAZORPAY WEBHOOK
========================================================= */

const razorpayWebhook = async (
  req,
  res
) => {

  try {

    console.log(
      "===================================="
    );

    console.log(
      "Webhook Received"
    );

    console.log(
      "===================================="
    );


    console.log(
      JSON.stringify(
        req.body,
        null,
        2
      )
    );


    const event =
      req.body.event;


    if (
      event !==
      "payment.captured"
    ) {

      console.log(
        "Ignored Event:",
        event
      );

      return res
        .status(200)
        .send("Ignored");

    }


    const payment =
      req.body
        .payload
        .payment
        .entity;


    const customerEmail =
      payment.email;

    const customerPhone =
      payment.contact;


    console.log(
      "Customer Email:",
      customerEmail
    );

    console.log(
      "Customer Phone:",
      customerPhone
    );


    console.log(
      "Sending Email..."
    );


    await transporter.sendMail({

      from:
        `"Wealthoria" <${process.env.EMAIL_FROM}>`,

      to:
        customerEmail,

      subject:
        "Wealthoria Webinar Access",

      html: `
        <div style="font-family:Arial;padding:20px">

          <h2>
            Thank You For Registering!
          </h2>

          <p>
            Your payment has been received successfully.
          </p>

          <p>
            <b>Webinar Link</b><br>
            https://YOUR-WEBINAR-LINK
          </p>

          <p>
            <b>VdoCipher Link</b><br>
            https://YOUR-VDOCIPHER-LINK
          </p>

          <p>
            Regards,<br>
            <b>Team Wealthoria</b>
          </p>

        </div>
      `

    });


    res
      .status(200)
      .send("OK");

  } catch (err) {

    console.error(
      "Webhook Error:",
      err
    );

    res
      .status(500)
      .send(
        "Webhook Error"
      );

  }

};


/* =========================================================
   EXPORTS
========================================================= */

module.exports = {

  createOrder,

  createCourseOrder,

  verifyCoursePayment,

  razorpayWebhook

};