const { sendEmail } = require("../services/emailService");
const seminarEmailTemplate = require("../utils/seminarEmailTemplate");

const registerSeminar = async (req, res) => {
  try {

    console.log("========== SEMINAR API HIT ==========");
    console.log(req.body);

    const {
      fullName,
      email,
      phone,
      place,
      paymentId,
      orderId,
      amount,
    } = req.body;

    if (!fullName || !email || !phone || !paymentId) {
      return res.status(400).json({
        success: false,
        message: "Missing required fields.",
      });
    }

    console.log("Seminar Register API Called");
    console.log("Sending email to:", email);

    await sendEmail({
      to: email,
      subject: "Seminar Registration Confirmation",
      html: seminarEmailTemplate(fullName),
    });

    console.log("Email sent successfully");

    return res.status(201).json({
      success: true,
      message: "Seminar Registration Successful",
    });

  } catch (err) {
    console.error(err);

    return res.status(500).json({
      success: false,
      message: err.message,
    });
  }
};

module.exports = {
  registerSeminar,
};