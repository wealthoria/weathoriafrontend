const Razorpay = require("razorpay");
const bcrypt = require("bcryptjs");

const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_KEY_SECRET
});


/* =========================================================
   FIREBASE ADMIN
========================================================= */

const {
  admin,
  db
} = require("../config/firebaseAdmin");


/* =========================================================
   CREATE RAZORPAY SUBSCRIPTION
========================================================= */

exports.createSubscription = async (req, res) => {

  try {

    const {
      name,
      email,
      phone,
      password
    } = req.body;


    /* =====================================================
       VALIDATION
    ===================================================== */

    if (
      !name ||
      !email ||
      !phone ||
      !password
    ) {

      return res.status(400).json({
        success: false,
        message:
          "Name, email, phone and password are required."
      });

    }


    const cleanName =
      String(name).trim();

    const cleanEmail =
      String(email)
        .trim()
        .toLowerCase();

    const cleanPhone =
      String(phone).trim();


    if (
      password.length < 6
    ) {

      return res.status(400).json({
        success: false,
        message:
          "Password must be at least 6 characters."
      });

    }


    /* =====================================================
       RAZORPAY PLAN
    ===================================================== */

    const planId =
      process.env.RAZORPAY_PLAN_ID;


    if (!planId) {

      return res.status(500).json({
        success: false,
        message:
          "RAZORPAY_PLAN_ID is not configured."
      });

    }


    console.log(
      "Creating Razorpay subscription:",
      {
        plan_id: planId,
        email: cleanEmail
      }
    );


    /* =====================================================
       CREATE RAZORPAY SUBSCRIPTION
    ===================================================== */

    const subscription =
      await razorpay.subscriptions.create({

        plan_id:
          planId,

        customer_notify:
          1,

        total_count:
          12,

        notes: {
          name:
            cleanName,

          email:
            cleanEmail,

          phone:
            cleanPhone
        }

      });


    console.log(
      "Razorpay subscription created:",
      subscription.id
    );


    /* =====================================================
       RESPONSE
    ===================================================== */

    return res.json({

      success:
        true,

      key:
        process.env.RAZORPAY_KEY_ID,

      subscriptionId:
        subscription.id,

      planId:
        planId

    });


  } catch (error) {

    console.error(
      "Razorpay create subscription error:",
      error
    );


    return res.status(
      error.statusCode || 500
    ).json({

      success:
        false,

      message:
        error.error?.description ||
        error.message ||
        "Unable to create subscription."

    });

  }

};


/* =========================================================
   COMPLETE SUBSCRIPTION
========================================================= */

exports.completeSubscription = async (req, res) => {

  try {

    const {
      name,
      email,
      phone,
      password,
      subscriptionId,
      paymentId
    } = req.body;


    /* =====================================================
       VALIDATION
    ===================================================== */

    if (
      !name ||
      !email ||
      !phone ||
      !password ||
      !subscriptionId ||
      !paymentId
    ) {

      return res.status(400).json({

        success:
          false,

        message:
          "Complete subscription information is required."

      });

    }


    const cleanName =
      String(name).trim();

    const cleanEmail =
      String(email)
        .trim()
        .toLowerCase();

    const cleanPhone =
      String(phone).trim();


    if (
      password.length < 6
    ) {

      return res.status(400).json({

        success:
          false,

        message:
          "Password must be at least 6 characters."

      });

    }


    /* =====================================================
       VERIFY RAZORPAY SUBSCRIPTION
    ===================================================== */

    let razorpaySubscription;

    try {

      razorpaySubscription =
        await razorpay
          .subscriptions
          .fetch(
            subscriptionId
          );

    } catch (error) {

      console.error(
        "Razorpay subscription verification error:",
        error
      );

      return res.status(400).json({

        success:
          false,

        message:
          "Unable to verify Razorpay subscription."

      });

    }


    console.log(
      "Verified Razorpay subscription:",
      razorpaySubscription
    );


    /* =====================================================
       CHECK SUBSCRIPTION STATUS
    ===================================================== */

    const validStatuses = [
      "active",
      "authenticated"
    ];


    if (
      !validStatuses.includes(
        razorpaySubscription.status
      )
    ) {

      return res.status(400).json({

        success:
          false,

        message:
          "Razorpay subscription has not been activated."

      });

    }


    /* =====================================================
       VERIFY PAYMENT
    ===================================================== */

    let razorpayPayment;

    try {

      razorpayPayment =
        await razorpay
          .payments
          .fetch(
            paymentId
          );

    } catch (error) {

      console.error(
        "Razorpay payment verification error:",
        error
      );

      return res.status(400).json({

        success:
          false,

        message:
          "Unable to verify Razorpay payment."

      });

    }


    console.log(
      "Verified Razorpay payment:",
      razorpayPayment
    );


    /* =====================================================
       PAYMENT STATUS
    ===================================================== */

    if (
      razorpayPayment.status !==
      "captured"
    ) {

      return res.status(400).json({

        success:
          false,

        message:
          "Payment has not been captured."

      });

    }


    /* =====================================================
       FIND EXISTING MEMBER
    ===================================================== */

    const memberSnapshot =
      await db
        .collection(
          "members"
        )
        .where(
          "email",
          "==",
          cleanEmail
        )
        .limit(1)
        .get();


    let memberId;


    /* =====================================================
       EXISTING MEMBER
    ===================================================== */

    if (
      !memberSnapshot.empty
    ) {

      const memberDoc =
        memberSnapshot.docs[0];

      memberId =
        memberDoc.id;


      console.log(
        "Existing member found:",
        memberId
      );


      /*
       * Keep the same existing member.
       *
       * We do not create another members document.
       *
       * We update the password because the user has
       * explicitly created a password during subscription.
       */

      const passwordHash =
        await bcrypt.hash(
          password,
          12
        );


      await memberDoc.ref.set(
        {

          uid:
            memberDoc.id,

          name:
            memberDoc.data().name ||
            cleanName,

          email:
            cleanEmail,

          phone:
            cleanPhone,

          passwordHash:
            passwordHash,

          role:
            memberDoc.data().role ||
            "member",

          status:
            "active",

          updatedAt:
            admin
              .firestore
              .FieldValue
              .serverTimestamp()

        },

        {
          merge:
            true
        }

      );

    }


    /* =====================================================
       NEW MEMBER
    ===================================================== */

    else {

      const passwordHash =
        await bcrypt.hash(
          password,
          12
        );


      const memberRef =
        db
          .collection(
            "members"
          )
          .doc();


      memberId =
        memberRef.id;


      await memberRef.set({

        uid:
          memberId,

        name:
          cleanName,

        email:
          cleanEmail,

        phone:
          cleanPhone,

        passwordHash:
          passwordHash,

        role:
          "member",

        status:
          "active",

        createdAt:
          admin
            .firestore
            .FieldValue
            .serverTimestamp()

      });


      console.log(
        "New member created:",
        memberId
      );

    }


    /* =====================================================
       GET PLAN DETAILS
       
       This gets the real amount from the Razorpay Plan.
       We don't trust the frontend amount.
    ===================================================== */

    let planAmount = 999;

    try {

      const plan =
        await razorpay
          .plans
          .fetch(
            razorpaySubscription.plan_id
          );


      if (
        plan &&
        plan.item &&
        typeof plan.item.amount ===
          "number"
      ) {

        planAmount =
          plan.item.amount / 100;

      }

    } catch (error) {

      console.warn(
        "Could not fetch Razorpay plan amount. Using 999.",
        error.message
      );

    }


    /* =====================================================
       CREATE SUBSCRIPTION FIRESTORE RECORD
       
       IMPORTANT:
       This happens AFTER successful payment.
    ===================================================== */

    const subscriptionRef =
      db
        .collection(
          "subscriptions"
        )
        .doc();


    await subscriptionRef.set({

      memberId:
        memberId,

      name:
        cleanName,

      email:
        cleanEmail,

      phone:
        cleanPhone,

      plan:
        "Wealthoria Premium - Yearly",

      planId:
        razorpaySubscription.plan_id,

      amount:
        planAmount,

      currency:
        "INR",

      razorpaySubscriptionId:
        subscriptionId,

      razorpayPaymentId:
        paymentId,

      customerId:
        razorpaySubscription.customer_id ||
        "",

      status:
        "active",

      subscriptionStartDate:
        new Date().toISOString(),

      nextBillingDate:
        razorpaySubscription.charge_at
          ? new Date(
              razorpaySubscription.charge_at * 1000
            ).toISOString()
          : "",

      createdAt:
        admin
          .firestore
          .FieldValue
          .serverTimestamp(),

      updatedAt:
        admin
          .firestore
          .FieldValue
          .serverTimestamp()

    });


    console.log(
      "Subscription saved:",
      subscriptionRef.id
    );


    /* =====================================================
       SUCCESS
    ===================================================== */

    return res.json({

      success:
        true,

      memberId:
        memberId,

      subscriptionDocId:
        subscriptionRef.id,

      message:
        "Member and subscription saved successfully."

    });


  } catch (error) {

    console.error(
      "Complete subscription error:",
      error
    );


    return res.status(500).json({

      success:
        false,

      message:
        error.message ||
        "Unable to complete subscription."

    });

  }

};