const axios = require("axios");

const VIDEO_ID = "368fd8f7617446e392ccf84277e15e82";

exports.getRecordedVideo = async (req, res) => {

    try {

        const response = await axios.post(

            `https://dev.vdocipher.com/api/videos/${VIDEO_ID}/otp`,

            {
                ttl: 300
            },

            {
                headers: {
                    Authorization: `Apisecret ${process.env.VDO_API_SECRET}`
                }
            }

        );

        res.json({
            success: true,
            otp: response.data.otp,
            playbackInfo: response.data.playbackInfo
        });

    } catch (err) {

        console.log(err.response?.data || err);

        res.json({
            success: false
        });

    }

};