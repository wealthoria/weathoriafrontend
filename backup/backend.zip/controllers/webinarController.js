const {
  createRegistration,
  checkEmailExists,getRegistrationCount,updateEmailStatus,
} = require("../models/webinarModel");


const { sendEmail } = require("../services/emailService");
const webinarLinkEmail = require("../utils/webinarLinkEmail");

// Check email before payment
const checkEmail = async (req, res) => {
  try {
    const { email } = req.query;

    console.log("Checking email:", email);

    const exists = await checkEmailExists(email);

    console.log("Exists:", exists);

    return res.json({
      exists,
    });
  } catch (err) {
    console.error("CHECK EMAIL ERROR:", err);

    return res.status(500).json({
      exists: false,
      message: err.message,
    });
  }
};
// Register after payment

const registerWebinar = async (req, res) => {
  try {
        console.log("===== REGISTER API CALLED =====");

     // Check registration limit
    const totalRegistrations = await getRegistrationCount();

    if (totalRegistrations >= 510) {
      return res.status(400).json({
        success: false,
        message: "Sorry! The webinar registration limit of 510 participants has been reached."
      });
    }

     
    const {
      fullName,
      email,
      phone,
      place,
      paymentId,
      amount,
    } = req.body;
    console.log("Registering:", email);

    if (!fullName || !email || !phone) {
      return res.status(400).json({
        success: false,
        message: "Please fill all required fields.",
      });
    }

 const result = await createRegistration({
  fullName,
  email,
  phone,
  place,
  paymentId,
  amount,
});

console.log("Registration saved:", email);
   
sendEmail({
  to: email,
  subject: "Your Wealthoria Webinar Link",
  html: webinarLinkEmail(
    fullName,
    "https://www.wealthoria.in/live-webinar.html"
  ),
})
.then(async () => {
  await updateEmailStatus(result.id, "sent");
  console.log("Email sent:", email);
})
.catch(async (emailError) => {
  console.error(emailError);

  try {
    await updateEmailStatus(result.id, "failed");
  } catch (dbError) {
    console.error(dbError);
  }
});

// Return immediately
return res.status(201).json({
  success: true,
  registrationId: result.id,
});
  } catch (err) {
    console.error(err);

    return res.status(500).json({
      success: false,
      message: err.message,
    });
  }
};

const checkSeats = async (req, res) => {
  try {
    const totalRegistrations = await getRegistrationCount();

    return res.json({
      success: true,
      seatsAvailable: totalRegistrations < 510,
      totalRegistrations,
    });
  } catch (err) {
    return res.status(500).json({
      success: false,
      message: err.message,
    });
  }
};

module.exports = {
  registerWebinar,
  checkEmail,
  checkSeats,
};