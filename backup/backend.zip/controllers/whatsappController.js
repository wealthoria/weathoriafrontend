const { sendWhatsAppMessage } = require("../services/whatsappService");

const sendTestMessage = async (req, res) => {
  try {
    let { phone } = req.body;

    if (!phone) {
      return res.status(400).json({
        success: false,
        message: "Phone number is required",
      });
    }

    phone = phone.replace(/\D/g, "");

    console.log("Received Phone:", phone);

    const result = await sendWhatsAppMessage(phone);

    return res.json({
      success: true,
      message: "WhatsApp sent successfully",
      result,
    });
  } catch (error) {
    console.error(
      "Controller Error:",
      JSON.stringify(error.response?.data || error.message, null, 2)
    );

    return res.status(500).json({
      success: false,
      error: error.response?.data || error.message,
    });
  }
};

module.exports = {
  sendTestMessage,
};