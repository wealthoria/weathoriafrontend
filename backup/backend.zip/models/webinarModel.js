const db = require("../config/db");

const createRegistration = async (data) => {
  const query = `
    INSERT INTO registrations
    (
      full_name,
      email,
      phone,
      place,
      amount,
      payment_status,
      transaction_id,
      payment_date
    )
    VALUES ($1,$2,$3,$4,$5,$6,$7,NOW())
    RETURNING id;
  `;

  const values = [
    data.fullName,
    data.email,
    data.phone,
    data.place,
    data.amount,
    "paid",
    data.paymentId,
  ];

  const result = await db.query(query, values);

  return result.rows[0];
};

const checkEmailExists = async (email) => {
  const result = await db.query(
    "SELECT id FROM registrations WHERE email = $1",
    [email]
  );

  return result.rows.length > 0;
};

const getPaidUser = async (email) => {
  const result = await db.query(
    `SELECT * FROM registrations
     WHERE email = $1
     AND payment_status = 'paid'
     LIMIT 1`,
    [email]
  );

  return result.rows[0];
};


const getRegistrationCount = async () => {
  const result = await db.query(
    "SELECT COUNT(*) AS total FROM registrations"
  );

  return parseInt(result.rows[0].total);
};


const updateEmailStatus = async (id, status) => {
  const query = `
    UPDATE registrations
    SET "Email_sent" = $1
    WHERE id = $2
  `;

  await db.query(query, [status, id]);
};
module.exports = {
  createRegistration,
  checkEmailExists,
  getPaidUser,
    getRegistrationCount,
    updateEmailStatus,
};