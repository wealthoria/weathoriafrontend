const express = require("express");
const { admin, db } = require("../config/firebaseAdmin");

const router = express.Router();

router.get("/members", async (req, res) => {
  try {
    const snapshot = await db
      .collection("members")
      .get();

    const members = snapshot.docs.map((doc) => {
      const data = doc.data();

      return {
        id: doc.id,
        uid: doc.id,
        name: data.name || data.fullName || "Member",
        email: data.email || "",
        hasNotificationToken: !!data.fcmToken
      };
    });

    res.json({
      success: true,
      members
    });
  } catch (error) {
    console.error("Load members error:", error);

    res.status(500).json({
      success: false,
      message: "Unable to load members."
    });
  }
});
router.post("/send", async (req, res) => {

  try {

    const userIds =
      Array.isArray(req.body.userIds)
        ? req.body.userIds
            .map((id) => String(id).trim())
            .filter(Boolean)
        : [];

    const title =
      String(
        req.body.title || ""
      ).trim();

    const message =
      String(
        req.body.message || ""
      ).trim();


    if (!userIds.length) {

      return res.status(400).json({
        success: false,
        message:
          "At least one member is required."
      });

    }


    if (!title) {

      return res.status(400).json({
        success: false,
        message:
          "Notification title is required."
      });

    }


    if (!message) {

      return res.status(400).json({
        success: false,
        message:
          "Notification message is required."
      });

    }


    let sentCount = 0;
    let skippedCount = 0;

    const notifications = [];


    for (const userId of userIds) {

      const memberRef =
        db
          .collection("members")
          .doc(userId);

      const memberDoc =
        await memberRef.get();


      if (!memberDoc.exists) {

        skippedCount++;
        continue;

      }


      const member =
        memberDoc.data();

      const fcmToken =
        String(
          member.fcmToken || ""
        ).trim();


      if (!fcmToken) {

        skippedCount++;
        continue;

      }


      try {

        const fcmMessageId =
          await admin.messaging().send({

            token: fcmToken,

            notification: {
              title,
              body: message
            },

            data: {
              type:
                "member_notification",

              title,

              body:
                message
            }

          });


        const notificationRef =
          await db
            .collection("notifications")
            .add({

              userId,

              title,

              message,

              read: false,

              fcmMessageId,

              createdAt:
                admin.firestore
                  .FieldValue
                  .serverTimestamp()

            });


        notifications.push({
          id:
            notificationRef.id,
          userId
        });


        sentCount++;


      } catch (sendError) {

        console.error(
          "FCM send failed for:",
          userId,
          sendError
        );

        skippedCount++;

      }

    }


    return res.json({

      success: true,

      message:
        `Notification sent to ${sentCount} member(s).`,

      sentCount,

      skippedCount,

      notifications

    });


  } catch (error) {

    console.error(
      "Bulk notification error:",
      error
    );

    return res.status(500).json({

      success: false,

      message:
        error.message ||
        "Unable to send notifications."

    });

  }

});

module.exports = router;