const express = require("express");
const multer = require("multer");
const path = require("path");
const fs = require("fs");

const router = express.Router();

/* =========================================================
   FOLDERS
========================================================= */

const pdfDirectory = path.join(
  __dirname,
  "..",
  "public",
  "members",
  "content-pdfs"
);

const thumbnailDirectory = path.join(
  __dirname,
  "..",
  "public",
  "members",
  "content-thumbnails"
);

/* =========================================================
   CREATE FOLDERS
========================================================= */

fs.mkdirSync(pdfDirectory, {
  recursive: true
});

fs.mkdirSync(thumbnailDirectory, {
  recursive: true
});

/* =========================================================
   MULTER STORAGE
========================================================= */

const storage = multer.diskStorage({

  destination: (req, file, cb) => {

    if (file.fieldname === "pdf") {
      cb(null, pdfDirectory);
      return;
    }

    if (file.fieldname === "thumbnail") {
      cb(null, thumbnailDirectory);
      return;
    }

    cb(
      new Error(
        "Invalid upload field."
      )
    );
  },

  filename: (req, file, cb) => {

    const ext = path.extname(
      file.originalname
    );

    const base = path
      .basename(
        file.originalname,
        ext
      )
      .toLowerCase()
      .replace(
        /[^a-z0-9]+/g,
        "-"
      )
      .replace(
        /^-|-$/g,
        ""
      );

    const filename =
      `${Date.now()}-${Math.random()
        .toString(36)
        .slice(2, 8)}-${base}${ext.toLowerCase()}`;

    cb(
      null,
      filename
    );
  }

});

/* =========================================================
   FILE FILTER
========================================================= */

function fileFilter(
  req,
  file,
  cb
) {

  /* PDF */

  if (
    file.fieldname === "pdf"
  ) {

    const validPdf =
      file.mimetype ===
        "application/pdf" ||
      path
        .extname(
          file.originalname
        )
        .toLowerCase() ===
        ".pdf";

    if (!validPdf) {

      return cb(
        new Error(
          "Only PDF files are allowed."
        )
      );

    }
  }

  /* THUMBNAIL */

  if (
    file.fieldname ===
    "thumbnail"
  ) {

    const validImage = [
      "image/jpeg",
      "image/png",
      "image/webp"
    ].includes(
      file.mimetype
    );

    if (!validImage) {

      return cb(
        new Error(
          "Thumbnail must be JPG, PNG or WebP."
        )
      );

    }
  }

  cb(
    null,
    true
  );
}

/* =========================================================
   MULTER
========================================================= */

const upload = multer({

  storage,

  fileFilter,

  limits: {
    fileSize:
      25 * 1024 * 1024
  }

});

/* =========================================================
   PDF UPLOAD
========================================================= */

router.post(
  "/upload-content-pdf",

  upload.single("pdf"),

  (req, res) => {

    try {

      if (!req.file) {

        return res
          .status(400)
          .json({

            success: false,

            message:
              "PDF file is required."

          });

      }

      console.log(
        "========== PDF UPLOAD =========="
      );

      console.log(
        "UPLOAD __dirname:",
        __dirname
      );

      console.log(
        "PDF directory:",
        pdfDirectory
      );

      console.log(
        "Filename:",
        req.file.filename
      );

      console.log(
        "Path:",
        req.file.path
      );

      console.log(
        "Exists:",
        fs.existsSync(
          req.file.path
        )
      );

      console.log(
        "================================"
      );

      const url =
        `/members/content-pdfs/${req.file.filename}`;

      return res.json({

        success: true,

        url,

        path:
          req.file.path,

        filename:
          req.file.filename,

        originalName:
          req.file.originalname,

        size:
          req.file.size,

        type:
          "pdf"

      });

    } catch (error) {

      console.error(
        "Content PDF upload error:",
        error
      );

      return res
        .status(500)
        .json({

          success: false,

          message:
            error.message ||
            "PDF upload failed."

        });

    }

  }
);

/* =========================================================
   THUMBNAIL UPLOAD
========================================================= */

router.post(
  "/upload-content-thumbnail",

  upload.single(
    "thumbnail"
  ),

  (req, res) => {

    try {

      if (!req.file) {

        return res
          .status(400)
          .json({

            success: false,

            message:
              "Thumbnail file is required."

          });

      }

      console.log(
        "======= THUMBNAIL UPLOAD ======="
      );

      console.log(
        "Thumbnail directory:",
        thumbnailDirectory
      );

      console.log(
        "Filename:",
        req.file.filename
      );

      console.log(
        "Path:",
        req.file.path
      );

      console.log(
        "Exists:",
        fs.existsSync(
          req.file.path
        )
      );

      console.log(
        "================================"
      );

      const url =
        `/members/content-thumbnails/${req.file.filename}`;

      return res.json({

        success: true,

        url,

        path:
          req.file.path,

        filename:
          req.file.filename,

        originalName:
          req.file.originalname,

        size:
          req.file.size,

        type:
          "thumbnail"

      });

    } catch (error) {

      console.error(
        "Content thumbnail upload error:",
        error
      );

      return res
        .status(500)
        .json({

          success: false,

          message:
            error.message ||
            "Thumbnail upload failed."

        });

    }

  }
);

/* =========================================================
   ERROR HANDLER
========================================================= */

router.use(
  (
    error,
    req,
    res,
    next
  ) => {

    console.error(
      "Content upload route error:",
      error
    );

    if (
      error instanceof
      multer.MulterError
    ) {

      if (
        error.code ===
        "LIMIT_FILE_SIZE"
      ) {

        return res
          .status(400)
          .json({

            success: false,

            message:
              "File is too large. Maximum size is 25 MB."

          });

      }
    }

    return res
      .status(400)
      .json({

        success: false,

        message:
          error.message ||
          "File upload failed."

      });

  }
);

/* =========================================================
   EXPORT
========================================================= */

module.exports =
  router;