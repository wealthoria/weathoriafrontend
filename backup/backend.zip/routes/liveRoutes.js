//const express = require("express");
//const router = express.Router();
//const { generateLiveToken } = require("../controllers/liveControllerold");

//router.get("/token", generateLiveToken);

//module.exports = router;


const express = require("express");
const router = express.Router();
const { generateLiveToken } = require("../controllers/liveController");

router.get("/token", generateLiveToken);

module.exports = router;