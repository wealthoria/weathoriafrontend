const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const { admin, db } =
  require("../config/firebaseAdmin");
const router = express.Router();


/* =========================================================
   CONFIG
========================================================= */

const JWT_SECRET =
  process.env.MEMBER_JWT_SECRET;


/* =========================================================
   CHECK JWT CONFIG
========================================================= */

if (!JWT_SECRET) {

  console.warn(
    "WARNING: MEMBER_JWT_SECRET is not configured."
  );

}


/* =========================================================
   AUTH MIDDLEWARE
========================================================= */

function requireMemberAuth(req, res, next) {

  try {

    const header =
      req.headers.authorization || "";


    if (
      !header.startsWith("Bearer ")
    ) {

      return res.status(401).json({
        success: false,
        message:
          "Authentication required."
      });

    }


    const token =
      header.substring(7);


    if (!JWT_SECRET) {

      return res.status(500).json({
        success: false,
        message:
          "Member authentication is not configured."
      });

    }


    const decoded =
      jwt.verify(
        token,
        JWT_SECRET
      );


    if (
      !decoded ||
      !decoded.uid
    ) {

      return res.status(401).json({
        success: false,
        message:
          "Invalid authentication token."
      });

    }


    req.member = decoded;

    next();

  } catch (error) {

    console.error(
      "Member auth middleware error:",
      error
    );


    return res.status(401).json({
      success: false,
      message:
        "Your login session has expired. Please login again."
    });

  }

}

/* =========================================================
   SAVE MEMBER FCM NOTIFICATION TOKEN
=========================================================

   POST /api/members/notification-token

   Header:
   Authorization: Bearer TOKEN

   Body:
   {
     token: "FCM_TOKEN"
   }

========================================================= */

router.post(
  "/notification-token",
  requireMemberAuth,
  async (req, res) => {

    try {

      /* -----------------------------------------
         GET MEMBER UID FROM VERIFIED JWT
      ----------------------------------------- */

      const uid =
        req.member.uid;


      /* -----------------------------------------
         GET FCM TOKEN
      ----------------------------------------- */

      const token =
        String(
          req.body.token || ""
        ).trim();


      /* -----------------------------------------
         VALIDATION
      ----------------------------------------- */

      if (!token) {

        return res.status(400).json({
          success: false,
          message:
            "FCM notification token is required."
        });

      }


      /* -----------------------------------------
         FIND MEMBER
      ----------------------------------------- */

      const memberRef =
        db
          .collection("members")
          .doc(uid);


      const memberDoc =
        await memberRef.get();


      if (!memberDoc.exists) {

        return res.status(404).json({
          success: false,
          message:
            "Member account was not found."
        });

      }


      /* -----------------------------------------
         SAVE FCM TOKEN
      ----------------------------------------- */

      await memberRef.set(
        {

          fcmToken:
            token,

          fcmTokenUpdatedAt:
            admin.firestore
              .FieldValue
              .serverTimestamp()

        },
        {
          merge: true
        }
      );


      console.log(
        "FCM token saved for member:",
        uid
      );


      /* -----------------------------------------
         SUCCESS
      ----------------------------------------- */

      return res.json({

        success:
          true,

        message:
          "Notification token saved successfully."

      });


    } catch (error) {

      console.error(
        "Save FCM token error:",
        error
      );


      return res.status(500).json({

        success:
          false,

        message:
          "Unable to save notification token."

      });

    }

  }
);
/* =========================================================
   FIND MEMBER BY EMAIL
========================================================= */

/* =========================================================
   GET MEMBER NOTIFICATIONS
   GET /api/members/notifications
========================================================= */

router.get(
  "/notifications",
  requireMemberAuth,
  async (req, res) => {

    try {

      const uid = req.member.uid;

      const snapshot =
        await db
          .collection("notifications")
          .where("userId", "==", uid)
          .get();

      const notifications =
        snapshot.docs
          .map((doc) => {

            const data = doc.data();

            return {
              id: doc.id,
              title: data.title || "",
              message: data.message || "",
              read: data.read === true,
              createdAt: data.createdAt || null
            };

          })
          .sort((a, b) => {

            const aTime =
              a.createdAt?.toMillis?.() || 0;

            const bTime =
              b.createdAt?.toMillis?.() || 0;

            return bTime - aTime;

          });

      const unreadCount =
        notifications.filter(
          (item) => item.read !== true
        ).length;

      return res.json({
        success: true,
        notifications,
        unreadCount
      });

    } catch (error) {

      console.error(
        "Get member notifications error:",
        error
      );

      return res.status(500).json({
        success: false,
        message:
          "Unable to load notifications."
      });

    }

  }
);


/* =========================================================
   MARK NOTIFICATION AS READ
   POST /api/members/notifications/:id/read
========================================================= */

router.post(
  "/notifications/:id/read",
  requireMemberAuth,
  async (req, res) => {

    try {

      const uid = req.member.uid;

      const notificationRef =
        db
          .collection("notifications")
          .doc(req.params.id);

      const notificationDoc =
        await notificationRef.get();

      if (!notificationDoc.exists) {

        return res.status(404).json({
          success: false,
          message:
            "Notification not found."
        });

      }

      const notification =
        notificationDoc.data();

      if (
        notification.userId !== uid
      ) {

        return res.status(403).json({
          success: false,
          message:
            "You cannot modify this notification."
        });

      }

      await notificationRef.update({

        read: true,

        readAt:
          admin.firestore
            .FieldValue
            .serverTimestamp()

      });

      return res.json({
        success: true
      });

    } catch (error) {

      console.error(
        "Mark notification read error:",
        error
      );

      return res.status(500).json({
        success: false,
        message:
          "Unable to mark notification as read."
      });

    }

  }
);

/* =========================================================
   SEND TEST NOTIFICATION TO CURRENT MEMBER
=========================================================

   POST /api/members/notification-test

   Header:
   Authorization: Bearer TOKEN

   This sends a test notification only to the
   currently logged-in member.

========================================================= */

router.post(
  "/notification-test",
  requireMemberAuth,
  async (req, res) => {
    try {
      /* -----------------------------------------
         GET UID FROM VERIFIED JWT
      ----------------------------------------- */

      const uid = req.member.uid;

      /* -----------------------------------------
         GET MEMBER
      ----------------------------------------- */

      const memberRef = db
        .collection("members")
        .doc(uid);

      const memberDoc = await memberRef.get();

      if (!memberDoc.exists) {
        return res.status(404).json({
          success: false,
          message: "Member account was not found."
        });
      }

      const member = memberDoc.data();

      /* -----------------------------------------
         GET FCM TOKEN
      ----------------------------------------- */

      const fcmToken = String(
        member.fcmToken || ""
      ).trim();

      if (!fcmToken) {
        return res.status(400).json({
          success: false,
          message:
            "This member does not have an FCM notification token."
        });
      }

      /* -----------------------------------------
         SEND FCM NOTIFICATION
      ----------------------------------------- */

      const message = {
        token: fcmToken,

        notification: {
          title: "Wealthoria 🔔",
          body: "This is a test notification from Wealthoria."
        },

        webpush: {
          notification: {
            title: "Wealthoria 🔔",
            body: "This is a test notification from Wealthoria.",
            icon: "/icons/icon-192.png"
          }
        },

        data: {
          type: "test",
          memberUid: uid
        }
      };

      const response =
        await admin.messaging().send(message);

      console.log(
        "✅ Test notification sent to member:",
        uid
      );

      console.log(
        "FCM message ID:",
        response
      );

      return res.json({
        success: true,
        message:
          "Test notification sent successfully.",
        messageId: response
      });

    } catch (error) {

      console.error(
        "❌ Send test notification error:",
        error
      );

      return res.status(500).json({
        success: false,
        message:
          "Unable to send test notification.",
        error:
          error.message
      });
    }
  }
);
/* =========================================================
   MEMBER LOGIN STATUS
   POST /api/members/login-status

   Header:
   Authorization: Bearer TOKEN

   Body:
   {
     uid,
     name,
     email,
     loginTime,
     status
   }
========================================================= */

router.post(
  "/login-status",
  requireMemberAuth,
  async (req, res) => {
    try {
      const uid = req.member.uid;

      const memberRef = db
        .collection("members")
        .doc(uid);

      const memberDoc = await memberRef.get();

      if (!memberDoc.exists) {
        return res.status(404).json({
          success: false,
          message: "Member account was not found."
        });
      }

      await memberRef.set(
        {
          lastLoginAt:
            admin.firestore.FieldValue.serverTimestamp(),

          lastSeenAt:
            admin.firestore.FieldValue.serverTimestamp(),

          lastLoginStatus:
            "online"
        },
        {
          merge: true
        }
      );

      console.log(
        "Member login status saved:",
        uid
      );

      return res.json({
        success: true,
        message: "Member login status saved successfully."
      });

    } catch (error) {
      console.error(
        "Member login status error:",
        error
      );

      return res.status(500).json({
        success: false,
        message:
          "Unable to save member login status."
      });
    }
  }
);


async function findMemberByEmail(email) {

  const snapshot =
    await db
      .collection("members")
      .where(
        "email",
        "==",
        email
      )
      .limit(1)
      .get();


  if (
    snapshot.empty
  ) {

    return null;

  }


  const doc =
    snapshot.docs[0];


  return {
    ref: doc.ref,
    id: doc.id,
    data: doc.data()
  };

}


/* =========================================================
   MEMBER LOGIN
=========================================================

   POST /api/members/login

   Body:
   {
     email,
     password
   }

========================================================= */

router.post(
  "/login",
  async (req, res) => {

    try {

      const email =
        String(
          req.body.email || ""
        )
          .trim()
          .toLowerCase();


      const password =
        String(
          req.body.password || ""
        );


      /* -----------------------------------------
         VALIDATION
      ----------------------------------------- */

      if (!email) {

        return res.status(400).json({
          success: false,
          message:
            "Email is required."
        });

      }


      if (!password) {

        return res.status(400).json({
          success: false,
          message:
            "Password is required."
        });

      }


      /* -----------------------------------------
         FIND MEMBER
      ----------------------------------------- */

      const memberRecord =
        await findMemberByEmail(
          email
        );


      if (!memberRecord) {

        return res.status(401).json({
          success: false,
          message:
            "Incorrect email or password."
        });

      }


      const member =
        memberRecord.data;


      /* -----------------------------------------
         ROLE CHECK
      ----------------------------------------- */

      const role =
        String(
          member.role || "member"
        ).toLowerCase();


      if (
        role !== "member"
      ) {

        return res.status(403).json({
          success: false,
          message:
            "You are not authorized to access the Members Portal."
        });

      }


      /* -----------------------------------------
         MEMBER UID
      ----------------------------------------- */

      const uid =
        member.uid ||
        memberRecord.id;


      /* =================================================
         PASSWORD VERIFICATION
      ================================================= */

      let passwordValid =
        false;


      /* -----------------------------------------
         SECURE HASH
      ----------------------------------------- */

      if (
        member.passwordHash
      ) {

        passwordValid =
          await bcrypt.compare(
            password,
            member.passwordHash
          );

      }


      /* -----------------------------------------
         LEGACY PLAINTEXT PASSWORD MIGRATION
      -----------------------------------------

         This allows your existing member record:

         password: "test@123"

         to work once.

         After successful login:

         password
              ↓
         passwordHash

         Then plaintext password is deleted.
      ----------------------------------------- */

      else if (
        member.password
      ) {

        passwordValid =
          password ===
          String(
            member.password
          );


        if (
          passwordValid
        ) {

          const passwordHash =
            await bcrypt.hash(
              password,
              12
            );


          await memberRecord.ref.set(
            {
              passwordHash:
                passwordHash
            },
            {
              merge: true
            }
          );


          await memberRecord.ref.update({
            password:
              admin.firestore
                .FieldValue
                .delete()
          });


          console.log(
            "Legacy password migrated for member:",
            uid
          );

        }

      }


      /* -----------------------------------------
         INVALID PASSWORD
      ----------------------------------------- */

      if (
        !passwordValid
      ) {

        return res.status(401).json({
          success: false,
          message:
            "Incorrect email or password."
        });

      }


      /* =================================================
         JWT
      ================================================= */

      if (!JWT_SECRET) {

        return res.status(500).json({
          success: false,
          message:
            "Member authentication is not configured on the server."
        });

      }


      const token =
        jwt.sign(
          {
            uid:
              uid,

            email:
              member.email ||
              email,

            role:
              role

          },
          JWT_SECRET,
          {
            expiresIn:
              "7d"
          }
        );



/* =========================================================
   SAVE MEMBER LOGIN ACTIVITY
========================================================= */

await memberRecord.ref.set(
  {
    lastLoginAt:
      admin.firestore.FieldValue.serverTimestamp(),

    lastSeenAt:
      admin.firestore.FieldValue.serverTimestamp(),

    lastLoginStatus:
      "online"
  },
  {
    merge: true
  }
);

console.log(
  "Member login activity saved:",
  uid
);

      /* =================================================
         RESPONSE
      ================================================= */

      return res.json({

        success:
          true,

        token:
          token,

        uid:
          uid,

        email:
          member.email ||
          email,

        name:
          member.name ||
          "",

        role:
          role

      });


    } catch (error) {

      console.error(
        "Member login error:",
        error
      );


      return res.status(500).json({
        success: false,
        message:
          "Unable to login at this time."
      });

    }

  }
);


/* =========================================================
   GET CURRENT MEMBER
=========================================================

   GET /api/members/me

   Header:
   Authorization: Bearer TOKEN

========================================================= */

router.get(
  "/me",
  requireMemberAuth,
  async (req, res) => {

    try {

      const uid =
        req.member.uid;


      const memberRef =
        db
          .collection("members")
          .doc(uid);


      const memberDoc =
        await memberRef.get();


      if (
        !memberDoc.exists
      ) {

        return res.status(404).json({
          success: false,
          message:
            "Member account was not found."
        });

      }


      const member =
        memberDoc.data();


      return res.json({

        success:
          true,

        member: {

  uid:
    member.uid ||
    uid,

  name:
    member.name ||
    "",

  email:
    member.email ||
    "",

  role:
    member.role ||
    "member",

  lastLoginAt:
    member.lastLoginAt ||
    null,

  lastSeenAt:
    member.lastSeenAt ||
    null,

  lastLoginStatus:
    member.lastLoginStatus ||
    "offline"

}

      });


    } catch (error) {

      console.error(
        "Get member error:",
        error
      );


      return res.status(500).json({
        success: false,
        message:
          "Unable to load member profile."
      });

    }

  }
);


/* =========================================================
   UPDATE MEMBER PROFILE
=========================================================

   PUT /api/members/profile

   Header:
   Authorization: Bearer TOKEN

   Body:
   {
     name,
     email
   }

========================================================= */

router.put(
  "/profile",
  requireMemberAuth,
  async (req, res) => {

    try {

      const uid =
        req.member.uid;


      const name =
        String(
          req.body.name || ""
        ).trim();


      const email =
        String(
          req.body.email || ""
        )
          .trim()
          .toLowerCase();


      /* -----------------------------------------
         VALIDATION
      ----------------------------------------- */

      if (!name) {

        return res.status(400).json({
          success: false,
          message:
            "Name is required."
        });

      }


      if (
        !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(
          email
        )
      ) {

        return res.status(400).json({
          success: false,
          message:
            "Please enter a valid email address."
        });

      }


      /* -----------------------------------------
         CURRENT MEMBER
      ----------------------------------------- */

      const memberRef =
        db
          .collection("members")
          .doc(uid);


      const memberDoc =
        await memberRef.get();


      if (
        !memberDoc.exists
      ) {

        return res.status(404).json({
          success: false,
          message:
            "Member account was not found."
        });

      }


      const currentMember =
        memberDoc.data();


      /* -----------------------------------------
         CHECK DUPLICATE EMAIL
      ----------------------------------------- */

      const emailSnapshot =
        await db
          .collection("members")
          .where(
            "email",
            "==",
            email
          )
          .limit(10)
          .get();


      const duplicate =
        emailSnapshot.docs.find(
          (doc) =>
            doc.id !== uid
        );


      if (
        duplicate
      ) {

        return res.status(409).json({
          success: false,
          message:
            "This email address is already registered."
        });

      }


      /* -----------------------------------------
         UPDATE FIRESTORE
      ----------------------------------------- */

      await memberRef.set(
        {
          name:
            name,

          email:
            email,

          updatedAt:
            admin.firestore
              .FieldValue
              .serverTimestamp()

        },
        {
          merge: true
        }
      );


      return res.json({

        success:
          true,

        message:
          "Profile updated successfully.",

        member: {

          uid:
            uid,

          name:
            name,

          email:
            email,

          role:
            currentMember.role ||
            "member"

        }

      });


    } catch (error) {

      console.error(
        "Member profile update error:",
        error
      );


      return res.status(500).json({
        success: false,
        message:
          "Unable to update member profile."
      });

    }

  }
);


/* =========================================================
   CHANGE PASSWORD
=========================================================

   POST /api/members/change-password

   Header:
   Authorization: Bearer TOKEN

   Body:
   {
     currentPassword,
     newPassword
   }

========================================================= */

router.post(
  "/change-password",
  requireMemberAuth,
  async (req, res) => {

    try {

      const uid =
        req.member.uid;


      const currentPassword =
        String(
          req.body.currentPassword || ""
        );


      const newPassword =
        String(
          req.body.newPassword || ""
        );


      /* -----------------------------------------
         VALIDATION
      ----------------------------------------- */

      if (!currentPassword) {

        return res.status(400).json({
          success: false,
          message:
            "Current password is required."
        });

      }


      if (!newPassword) {

        return res.status(400).json({
          success: false,
          message:
            "New password is required."
        });

      }


      if (
        newPassword.length < 6
      ) {

        return res.status(400).json({
          success: false,
          message:
            "New password must be at least 6 characters."
        });

      }


      /* -----------------------------------------
         GET MEMBER
      ----------------------------------------- */

      const memberRef =
        db
          .collection("members")
          .doc(uid);


      const memberDoc =
        await memberRef.get();


      if (
        !memberDoc.exists
      ) {

        return res.status(404).json({
          success: false,
          message:
            "Member account was not found."
        });

      }


      const member =
        memberDoc.data();


      /* -----------------------------------------
         REQUIRE SECURE HASH
      ----------------------------------------- */

      if (
        !member.passwordHash
      ) {

        return res.status(400).json({
          success: false,
          message:
            "Please login once first so the old password can be securely migrated."
        });

      }


      /* -----------------------------------------
         CHECK CURRENT PASSWORD
      ----------------------------------------- */

      const currentPasswordValid =
        await bcrypt.compare(
          currentPassword,
          member.passwordHash
        );


      if (
        !currentPasswordValid
      ) {

        return res.status(401).json({
          success: false,
          message:
            "Current password is incorrect."
        });

      }


      /* -----------------------------------------
         DON'T ALLOW SAME PASSWORD
      ----------------------------------------- */

      const samePassword =
        await bcrypt.compare(
          newPassword,
          member.passwordHash
        );


      if (
        samePassword
      ) {

        return res.status(400).json({
          success: false,
          message:
            "New password must be different from your current password."
        });

      }


      /* -----------------------------------------
         CREATE NEW HASH
      ----------------------------------------- */

      const newPasswordHash =
        await bcrypt.hash(
          newPassword,
          12
        );


      /* -----------------------------------------
         SAVE NEW HASH
      ----------------------------------------- */

      await memberRef.set(
        {
          passwordHash:
            newPasswordHash,

          passwordUpdatedAt:
            admin.firestore
              .FieldValue
              .serverTimestamp(),

          updatedAt:
            admin.firestore
              .FieldValue
              .serverTimestamp()

        },
        {
          merge: true
        }
      );


      /* -----------------------------------------
         REMOVE OLD PLAINTEXT PASSWORD
      ----------------------------------------- */

      if (
        Object.prototype.hasOwnProperty.call(
          member,
          "password"
        )
      ) {

        await memberRef.update({

          password:
            admin.firestore
              .FieldValue
              .delete()

        });

      }


      return res.json({

        success:
          true,

        message:
          "Password updated successfully."

      });


    } catch (error) {

      console.error(
        "Member change password error:",
        error
      );


      return res.status(500).json({
        success: false,
        message:
          "Unable to change password."
      });

    }

  }
);


/* =========================================================
   LOGOUT
========================================================= */
router.post(
  "/logout",
  requireMemberAuth,
  async (req, res) => {

    try {

      const uid =
        req.member.uid;

      await db
        .collection("members")
        .doc(uid)
        .set(
          {
            lastSeenAt:
              admin.firestore.FieldValue.serverTimestamp(),

            lastLogoutAt:
              admin.firestore.FieldValue.serverTimestamp(),

            lastLoginStatus:
              "offline"
          },
          {
            merge: true
          }
        );

      console.log(
        "Member logged out:",
        uid
      );

      return res.json({

        success:
          true,

        message:
          "Logged out successfully."

      });

    } catch (error) {

      console.error(
        "Member logout error:",
        error
      );

      return res.status(500).json({

        success:
          false,

        message:
          "Unable to record logout."

      });

    }

  }
);

/* =========================================================
   EXPORT
========================================================= */

module.exports = router;