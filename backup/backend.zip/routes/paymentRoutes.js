const express = require("express");
const router = express.Router();

const {
  createOrder,
  createCourseOrder,
  verifyCoursePayment,
  razorpayWebhook,
} = require("../controllers/paymentController");


router.get("/test", (req, res) => {
  res.json({
    success: true,
    message: "Payment route working",
  });
});

router.post("/create-order", createOrder);

router.post(
  "/create-course-order",
  createCourseOrder
);

router.post(
  "/verify-course-payment",
  verifyCoursePayment
);

// Razorpay Webhook
router.post("/razorpay-webhook", razorpayWebhook);

module.exports = router;