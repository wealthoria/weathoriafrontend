const express = require("express");
const router = express.Router();

const {
    registerSeminar
} = require("../controllers/seminarController");

router.post("/register", registerSeminar);

module.exports = router;