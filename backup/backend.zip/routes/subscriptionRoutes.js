const express = require("express");

const router =
  express.Router();


const {
  createSubscription,
  completeSubscription
} =
  require(
    "../controllers/subscriptionController"
  );


/* =========================================================
   TEST
========================================================= */

router.get(
  "/test",
  (req, res) => {

    res.json({

      success:
        true,

      message:
        "Subscription API Working"

    });

  }
);


/* =========================================================
   CREATE RAZORPAY SUBSCRIPTION
========================================================= */

router.post(
  "/create",
  createSubscription
);


/* =========================================================
   COMPLETE AFTER SUCCESSFUL PAYMENT
========================================================= */

router.post(
  "/complete",
  completeSubscription
);


/* =========================================================
   EXPORT
========================================================= */

module.exports =
  router;