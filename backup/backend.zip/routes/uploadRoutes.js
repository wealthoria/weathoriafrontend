const express = require("express");
const multer = require("multer");
const path = require("path");
const fs = require("fs");

const router = express.Router();

/* =========================================================
   UPLOAD DIRECTORY
========================================================= */

const uploadDir = path.join(
  __dirname,
  "..",
  "public",
  "members",
  "course-thumbnails"
);

fs.mkdirSync(uploadDir, {
  recursive: true
});


/* =========================================================
   MULTER STORAGE
========================================================= */

const storage = multer.diskStorage({

  destination: (req, file, cb) => {
    cb(null, uploadDir);
  },

  filename: (req, file, cb) => {

    const ext =
      path.extname(file.originalname)
        .toLowerCase();

    const base =
      (req.body.courseTitle || "course")
        .toString()
        .trim()
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/^-+|-+$/g, "");

    const unique =
      Date.now() +
      "-" +
      Math.round(Math.random() * 1e9);

    cb(
      null,
      `${base || "course"}-${unique}${ext}`
    );

  }

});


/* =========================================================
   FILE FILTER
========================================================= */

const fileFilter = (req, file, cb) => {

  const allowed = [
    "image/png",
    "image/jpeg",
    "image/webp"
  ];

  if (allowed.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(
      new Error(
        "Only PNG, JPG and WebP images are allowed."
      )
    );
  }

};


const upload = multer({

  storage,

  fileFilter,

  limits: {
    fileSize: 5 * 1024 * 1024
  }

});


/* =========================================================
   UPLOAD COURSE THUMBNAIL
========================================================= */

router.post(
  "/upload-course-thumbnail",
  upload.single("thumbnail"),
  (req, res) => {

    try {

      if (!req.file) {

        return res.status(400).json({
          success: false,
          message: "Thumbnail file is required."
        });

      }

      const baseUrl =
        `${req.protocol}://${req.get("host")}`;

      const url =
        `${baseUrl}/members/course-thumbnails/${req.file.filename}`;

      console.log(
        "Course thumbnail uploaded:",
        url
      );

      return res.json({
        success: true,
        url
      });

    } catch (error) {

      console.error(
        "Thumbnail upload error:",
        error
      );

      return res.status(500).json({
        success: false,
        message:
          error.message ||
          "Thumbnail upload failed."
      });

    }

  }
);


/* =========================================================
   MULTER ERROR HANDLER
========================================================= */

router.use((error, req, res, next) => {

  if (
    error instanceof multer.MulterError
  ) {

    if (
      error.code ===
      "LIMIT_FILE_SIZE"
    ) {

      return res.status(400).json({
        success: false,
        message:
          "Thumbnail must be smaller than 5 MB."
      });

    }

  }

  if (error) {

    return res.status(400).json({
      success: false,
      message: error.message
    });

  }

  next();

});


module.exports = router;