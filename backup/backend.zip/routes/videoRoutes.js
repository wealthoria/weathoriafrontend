const express = require("express");
const router = express.Router();

const { getRecordedVideo } = require("../controllers/videoController");

router.get("/recording", getRecordedVideo);

module.exports = router;