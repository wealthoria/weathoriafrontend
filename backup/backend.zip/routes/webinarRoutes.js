const express = require("express");

const router = express.Router();

const {
  registerWebinar,
  checkEmail,
   checkSeats,
} = require("../controllers/webinarController");

router.get("/check-email", checkEmail);
router.get("/check-seats", checkSeats);

router.post("/register", registerWebinar);

module.exports = router;