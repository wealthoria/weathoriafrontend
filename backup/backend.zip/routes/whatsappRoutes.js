const express = require("express");
const router = express.Router();
const { sendTestMessage } = require("../controllers/whatsappController");

// Existing route
router.post("/send-test", sendTestMessage);

// Webhook verification
router.get("/webhook", (req, res) => {
  const VERIFY_TOKEN = process.env.WHATSAPP_VERIFY_TOKEN;

  const mode = req.query["hub.mode"];
  const token = req.query["hub.verify_token"];
  const challenge = req.query["hub.challenge"];

  console.log("Mode:", mode);
  console.log("Meta Token:", token);
  console.log("Env Token:", VERIFY_TOKEN);
  console.log("Challenge:", challenge);

  if (mode === "subscribe" && token === VERIFY_TOKEN) {
    console.log("Webhook verified successfully");
    return res.status(200).send(challenge);
  }

  console.log("Webhook verification failed");
  return res.sendStatus(403);
});

// Receive webhook events
router.post("/webhook", (req, res) => {
  console.log(
    "Webhook Event:",
    JSON.stringify(req.body, null, 2)
  );

  res.sendStatus(200);
});

module.exports = router;