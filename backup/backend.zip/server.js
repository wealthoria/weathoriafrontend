const liveRoutes = require("./routes/liveRoutes");
const express = require("express");
const cors = require("cors");
require("dotenv").config();
const path = require("path");
const dns = require("dns");
const net = require("net");

const db = require("./config/db");
const webinarRoutes = require("./routes/webinarRoutes");
const paymentRoutes = require("./routes/paymentRoutes");
const subscriptionRoutes = require("./routes/subscriptionRoutes");
const seminarRoutes = require("./routes/seminarRoutes");
const uploadRoutes = require("./routes/uploadRoutes");
const memberRoutes = require("./routes/memberRoutes");
const contentUploadRoutes = require("./routes/contentUploadRoutes");
const adminNotificationsRoutes =
  require("./routes/adminNotifications");




const app = express();

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.get("/", (req, res) => {
  res.json({
    message: "Backend Updated",
    smtpHost: process.env.SMTP_HOST,
    smtpEmail: process.env.SMTP_EMAIL,
  });
});
app.use("/api/webinar", webinarRoutes);
console.log("Payment Routes Object:", paymentRoutes);
app.get("/api/payment/test", (req, res) => {
  res.json({
    success: true,
    message: "Payment API Working",
  });
});

app.use("/api/payment", paymentRoutes);
app.use("/api/live", liveRoutes);
const PORT = process.env.PORT || 5000;
const { sendEmail } = require("./services/emailService");
const whatsappRoutes = require("./routes/whatsappRoutes");


app.use("/api/whatsapp", whatsappRoutes);
app.use("/api/subscription", subscriptionRoutes);
app.use("/api/seminar", seminarRoutes);

app.get("/dns-test", (req, res) => {
  dns.lookup("smtp.hostinger.com", { all: true }, (err, addresses) => {
    if (err) {
      return res.json(err);
    }
    res.json(addresses);
  });
});


app.get("/smtp-connect-test", (req, res) => {
  const socket = net.createConnection(
    {
      host: "smtp.hostinger.com",
      port: 587,
      family: 4,
    },
    () => {
      socket.end();
      res.json({
        success: true,
        message: "TCP connection successful",
      });
    }
  );

  socket.on("error", (err) => {
    res.status(500).json({
      success: false,
      code: err.code,
      error: err.message,
    });
  });

  socket.setTimeout(10000, () => {
    socket.destroy();
    res.status(500).json({
      success: false,
      error: "Connection timeout",
    });
  });
});

app.use(
  "/api",
  uploadRoutes
);

app.use(
  "/members/course-thumbnails",
  express.static(
    path.join(
      __dirname,
      "public",
      "members",
      "course-thumbnails"
    )
  )
);

app.use(
  "/api",
  contentUploadRoutes
);

app.use(
  "/members/content-pdfs",
  express.static(
    path.join(
      __dirname,
      "public",
      "members",
      "content-pdfs"
    )
  )
);

app.use(
  "/members/content-thumbnails",
  express.static(
    path.join(
      __dirname,
      "public",
      "members",
      "content-thumbnails"
    )
  )
);


app.use(
  "/api/admin/notifications",
  adminNotificationsRoutes
);
app.use("/api/members", memberRoutes);
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});