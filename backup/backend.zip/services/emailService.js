const { Resend } = require("resend");

const resend = new Resend(process.env.RESEND_API_KEY);

async function sendEmail({ to, subject, html, bcc }) {
  console.log("Sending email using Resend...");

  const { data, error } = await resend.emails.send({
    from: `Wealthoria <${process.env.EMAIL_FROM}>`,
    to,
    bcc,
    subject,
    html,
  });

  if (error) {
    console.error(error);
    throw new Error(error.message);
  }

  console.log("Email sent successfully");
  return data;
}

module.exports = { sendEmail };