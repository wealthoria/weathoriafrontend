const axios = require("axios");

const sendWhatsAppMessage = async (phone) => {
  try {
    console.log("Sending WhatsApp to:", phone);

    const response = await axios.post(
      `https://graph.facebook.com/v23.0/${process.env.WHATSAPP_PHONE_NUMBER_ID}/messages`,
      {
        messaging_product: "whatsapp",
        to: phone,
        type: "template",
        template: {
          name: "hello_world",
          language: {
            code: "en_US",
          },
        },
      },
      {
        headers: {
          Authorization: `Bearer ${process.env.WHATSAPP_ACCESS_TOKEN}`,
          "Content-Type": "application/json",
        },
      }
    );

    return response.data;
  } catch (err) {
    console.error(
      "WhatsApp Error:",
      JSON.stringify(err.response?.data, null, 2)
    );
    throw err;
  }
};

module.exports = {
  sendWhatsAppMessage,
};