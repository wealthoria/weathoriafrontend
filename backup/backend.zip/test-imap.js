require("dotenv").config();
console.log("EMAIL:", process.env.SMTP_EMAIL);
console.log("PASSWORD:", process.env.SMTP_PASSWORD ? "Loaded" : "Not Loaded");
const { ImapFlow } = require("imapflow");

async function test() {
  const client = new ImapFlow({
    host: "imap.hostinger.com",
    port: 993,
    secure: true,
    auth: {
      user: process.env.SMTP_EMAIL,
      pass: process.env.SMTP_PASSWORD,
    },
  });

  await client.connect();

  console.log("Connected!");

  const boxes = await client.list();

  console.log(boxes);

  await client.logout();
}

test().catch(console.error);