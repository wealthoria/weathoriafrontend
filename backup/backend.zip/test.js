const nodemailer = require("nodemailer");

const transporter = nodemailer.createTransport({
  host: "smtp.hostinger.com",
  port: 465,
  secure: true,
  auth: {
    user: "support@wealthoria.in",
    pass: "Wealthoria@2026", // Replace with your mailbox password
  },
});

(async () => {
  try {
    console.log("Verifying SMTP...");
    await transporter.verify();
    console.log("✅ SMTP Connected");

    const info = await transporter.sendMail({
      from: '"Wealthoria" <support@wealthoria.in>',
      to: "anju09745@gmail.com",
      subject: "SMTP Test",
      text: "This is a test email from Node.js",
    });

    console.log("✅ Email Sent");
    console.log(info);
  } catch (err) {
    console.error(err);
  }
})();