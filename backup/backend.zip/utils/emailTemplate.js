const registrationEmail = (name) => {
  return `
    <div style="font-family: Arial, sans-serif; padding: 20px; max-width: 600px; margin: auto;">
      
      <h2 style="color:#0F766E;">🎉 Payment & Registration Successful</h2>

      <p>Hello <strong>${name}</strong>,</p>

      <p>Thank you for registering for the <strong>Wealthoria Live Webinar</strong>.</p>

      <p>Your payment has been received successfully and your seat has been confirmed.</p>

      <div style="background:#f5f5f5;padding:15px;border-radius:8px;margin:20px 0;">
        <p><strong>✅ Registration Status:</strong> Confirmed</p>
        <p><strong>✅ Payment Status:</strong> Successful</p>
      </div>

      <p>
        We will send the webinar joining link and further instructions to this email before the event.
      </p>

      <br>

      <p>Thank you for choosing Wealthoria.</p>

      <p>
        Regards,<br>
        <strong>Team Wealthoria</strong>
      </p>

    </div>
  `;
};

module.exports = registrationEmail;