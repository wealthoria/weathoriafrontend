const seminarEmailTemplate = (fullName) => {
  return `
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Registration Confirmed</title>
</head>

<body style="margin:0;padding:0;background:#f4f6f9;font-family:Arial,sans-serif;">

<table width="100%" cellpadding="0" cellspacing="0" style="padding:40px 0;">
<tr>
<td align="center">

<table width="650" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 10px 30px rgba(0,0,0,.1);">

<!-- Header -->
<tr>
<td align="center" style="background:#e8473f;padding:35px;">
<h1 style="margin:0;color:#fff;font-size:34px;">
WEALTHORIA
</h1>

<p style="color:#fff;margin-top:10px;font-size:18px;">
Retirement & Wealth Planning Workshop
</p>
</td>
</tr>

<!-- Body -->
<tr>
<td style="padding:40px;">

<h2 style="color:#222;">
Hello ${fullName},
</h2>

<p style="font-size:17px;color:#555;line-height:30px;">
Thank you for registering for the
<b>Retirement & Wealth Planning Workshop.</b>

Your payment has been received successfully and your registration is confirmed.
</p>

<table width="100%" cellpadding="15" cellspacing="0"
style="margin-top:25px;background:#fafafa;border:1px solid #eee;border-radius:8px;">

<tr>
<td width="40%"><strong>Status</strong></td>
<td style="color:green;font-weight:bold;">
✅ Registration Confirmed
</td>
</tr>

<tr>
<td><strong>Workshop Date</strong></td>
<td>16 August 2026</td>
</tr>

<tr>
<td><strong>Time</strong></td>
<td>10:00 AM</td>
</tr>

<tr>
<td><strong>Venue</strong></td>
<td>No 2687/1, 2nd floor, 5th Cross, Kalidasa Road, Vani Vilas Mohalla (VV Mohalla), Mysore - 570002</td>
</tr>

<tr>
<td><strong>Participant</strong></td>
<td>${fullName}</td>
</tr>

</table>

<div style="margin-top:35px;text-align:center;">

<a href="https://wealthoria.in"
style="
display:inline-block;
background:#e8473f;
padding:15px 35px;
color:#fff;
text-decoration:none;
border-radius:8px;
font-size:18px;
font-weight:bold;">
Visit Wealthoria
</a>

</div>

<p style="margin-top:40px;font-size:16px;color:#555;line-height:28px;">
📌 Please arrive at least <b>15 minutes before the workshop starts.</b>

<br><br>

If you have any questions, contact us anytime at

<br>

<b>support@wealthoria.in</b>

</p>

</td>
</tr>

<!-- Footer -->

<tr>
<td align="center"
style="background:#222;color:#fff;padding:25px;font-size:14px;">

© 2026 Wealthoria. All Rights Reserved.

</td>
</tr>

</table>

</td>
</tr>

</table>

</body>
</html>
`;
};

module.exports = seminarEmailTemplate;