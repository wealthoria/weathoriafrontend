const webinarLinkEmail = (name, webinarLink) => {
  return `
    <div style="font-family: Arial, sans-serif; padding:20px;">
      <h2>🎥 Your Webinar Link</h2>

      <p>Hello <b>${name}</b>,</p>

      <p>Your webinar link is ready.</p>

      <p>
        <a href="${webinarLink}">
          Click here to join the webinar
        </a>
      </p>

      <p>Regards,<br><b>Wealthoria Team</b></p>
    </div>
  `;
};

module.exports = webinarLinkEmail;